---
name: Temporary Python tools
description: Replit's Python package installer can leave project configuration changes after one-time document processing.
---

Installing PyMuPDF in this Node workspace added Python and Nix configuration to `.replit` and generated a temporary `uv` project. Uninstalling the Python module did not remove every generated configuration entry.

**Why:** a one-time document inspection should not add unrelated runtime configuration or dependencies to the app.

**How to apply:** After temporary Python tooling, inspect the generated files and configuration. Restore `.replit` only through its validation flow, then remove only the temporary files created by the package installer.
