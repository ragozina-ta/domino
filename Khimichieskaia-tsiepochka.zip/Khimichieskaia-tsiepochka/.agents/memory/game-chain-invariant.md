---
name: Game chain invariant
description: Preserve a playable path when dealing randomized chemistry domino cards.
---

The hand and draw pile must be a connected sequence: each card's needed names correspond to the next card's formula through `formulaToNames`.

**Why:** selecting and shuffling an arbitrary subset with fixed needs can leave the player without any valid next card, especially in shorter games.

**How to apply:** When changing game generation or dealing, preserve or regenerate each card's next-substance names after shuffling, and keep the next valid card reachable through the current hand/draw order.
