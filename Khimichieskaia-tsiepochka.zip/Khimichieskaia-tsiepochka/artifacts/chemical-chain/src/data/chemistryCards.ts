export type SubstanceClass =
  | 'соль'
  | 'оксид'
  | 'кислота'
  | 'основание'
  | 'простое вещество'
  | 'другое соединение';

export type ChemistryCard = {
  id: string;
  formula: string;
  names: string[];
  substanceClass: SubstanceClass;
  hint1: string;
  fact: string;
};

type ChemistryCardBase = Omit<ChemistryCard, 'hint1' | 'fact'>;

export type GameCard = ChemistryCard & {
  needs: string[];
};

export type PreparedGame = {
  cards: GameCard[];
  startingCard: GameCard;
};

const chemistryCardsBase: ChemistryCardBase[] = [
  {
    id: 'card-01',
    formula: 'Br₂',
    names: ['бромная вода'],
    substanceClass: 'простое вещество',
  },
  {
    id: 'card-02',
    formula: 'NaNO₃',
    names: ['натриевая селитра', 'чилийская селитра'],
    substanceClass: 'соль',
  },
  {
    id: 'card-03',
    formula: 'H₂O',
    names: ['вода', 'лёд'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-04',
    formula: 'NaOH',
    names: ['едкий натр', 'каустик', 'каустическая сода'],
    substanceClass: 'основание',
  },
  {
    id: 'card-05',
    formula: 'FeCl₂',
    names: ['хлористое железо'],
    substanceClass: 'соль',
  },
  {
    id: 'card-06',
    formula: 'PH₃',
    names: ['фосфин'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-07',
    formula: 'NaCl',
    names: ['поваренная соль', 'каменная соль', 'пищевая соль'],
    substanceClass: 'соль',
  },
  {
    id: 'card-08',
    formula: 'Al₂O₃·nH₂O',
    names: ['боксит'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-09',
    formula: 'CaCO₃',
    names: ['мел', 'мрамор', 'известняк'],
    substanceClass: 'соль',
  },
  {
    id: 'card-10',
    formula: 'SO₃',
    names: ['серный газ', 'серный ангидрид'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-11',
    formula: 'SO₃·H₂SO₄',
    names: ['олеум'],
    substanceClass: 'кислота',
  },
  {
    id: 'card-12',
    formula: 'Ca(OH)₂',
    names: ['гашёная известь', 'известковая вода', 'известковое молоко'],
    substanceClass: 'основание',
  },
  {
    id: 'card-13',
    formula: 'KClO₃',
    names: ['бертолетова соль'],
    substanceClass: 'соль',
  },
  {
    id: 'card-14',
    formula: 'CS₂',
    names: ['сероуглерод'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-15',
    formula: 'Ca(H₂PO₄)₂',
    names: ['двойной суперфосфат'],
    substanceClass: 'соль',
  },
  {
    id: 'card-16',
    formula: 'TiO₂',
    names: ['титановые белила'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-17',
    formula: 'Na₂SO₄',
    names: ['глауберова соль'],
    substanceClass: 'соль',
  },
  {
    id: 'card-18',
    formula: 'NH₃',
    names: ['аммиак'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-19',
    formula: 'CaSO₄',
    names: ['гипс'],
    substanceClass: 'соль',
  },
  {
    id: 'card-20',
    formula: 'Fe₃O₄',
    names: ['железная окалина'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-21',
    formula: 'SiC',
    names: ['карборунд'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-22',
    formula: 'NaHCO₃',
    names: ['питьевая сода', 'пищевая сода'],
    substanceClass: 'соль',
  },
  {
    id: 'card-23',
    formula: 'C',
    names: ['графит', 'алмаз'],
    substanceClass: 'простое вещество',
  },
  {
    id: 'card-24',
    formula: 'FeCl₃',
    names: ['хлорное железо'],
    substanceClass: 'соль',
  },
  {
    id: 'card-25',
    formula: 'CO',
    names: ['угарный газ'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-26',
    formula: 'KAl(SO₄)₂',
    names: ['алюмокалиевые квасцы'],
    substanceClass: 'соль',
  },
  {
    id: 'card-27',
    formula: 'SO₂',
    names: ['сернистый газ', 'сернистый ангидрид'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-28',
    formula: 'O₃',
    names: ['озон'],
    substanceClass: 'простое вещество',
  },
  {
    id: 'card-29',
    formula: 'HgS',
    names: ['киноварь'],
    substanceClass: 'соль',
  },
  {
    id: 'card-30',
    formula: 'N₂O',
    names: ['веселящий газ'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-31',
    formula: 'FeSO₄',
    names: ['железный купорос'],
    substanceClass: 'соль',
  },
  {
    id: 'card-32',
    formula: 'P₂O₅',
    names: ['фосфорный ангидрид'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-33',
    formula: 'HCl',
    names: ['соляная кислота'],
    substanceClass: 'кислота',
  },
  {
    id: 'card-34',
    formula: 'K₂CO₃',
    names: ['поташ'],
    substanceClass: 'соль',
  },
  {
    id: 'card-35',
    formula: 'ZnO',
    names: ['цинковые белила'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-36',
    formula: 'FeS₂',
    names: ['пирит', 'железный колчедан'],
    substanceClass: 'соль',
  },
  {
    id: 'card-37',
    formula: 'KOH',
    names: ['едкий калий', 'едкое кали'],
    substanceClass: 'основание',
  },
  {
    id: 'card-38',
    formula: 'Pb₃O₄',
    names: ['свинцовый сурик'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-39',
    formula: 'ZnSO₄',
    names: ['цинковый купорос'],
    substanceClass: 'соль',
  },
  {
    id: 'card-40',
    formula: 'SiH₄',
    names: ['силан'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-41',
    formula: 'CuSO₄',
    names: ['медный купорос'],
    substanceClass: 'соль',
  },
  {
    id: 'card-42',
    formula: 'SiO₂',
    names: ['кварц', 'кремнезём', 'песок'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-43',
    formula: 'NH₃·H₂O',
    names: ['нашатырный спирт', 'гидрат аммиака'],
    substanceClass: 'основание',
  },
  {
    id: 'card-44',
    formula: 'NH₄Cl',
    names: ['нашатырь'],
    substanceClass: 'соль',
  },
  {
    id: 'card-45',
    formula: 'HF',
    names: ['плавиковая кислота'],
    substanceClass: 'кислота',
  },
  {
    id: 'card-46',
    formula: 'NO₂',
    names: ['бурый газ', 'лисий хвост'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-47',
    formula: 'ZnS',
    names: ['цинковая обманка'],
    substanceClass: 'соль',
  },
  {
    id: 'card-48',
    formula: '[Ag(NH₃)₂]OH',
    names: ['гидроксид диамминсеребра'],
    substanceClass: 'основание',
  },
  {
    id: 'card-49',
    formula: 'COCl₂',
    names: ['фосген'],
    substanceClass: 'другое соединение',
  },
  {
    id: 'card-50',
    formula: '(CuOH)₂CO₃',
    names: ['малахит'],
    substanceClass: 'соль',
  },
  {
    id: 'card-51',
    formula: 'CaO',
    names: ['негашёная известь'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-52',
    formula: 'NH₄NO₃',
    names: ['аммиачная селитра'],
    substanceClass: 'соль',
  },
  {
    id: 'card-53',
    formula: 'MgO',
    names: ['жжёная магнезия'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-54',
    formula: 'Na₂CO₃',
    names: ['кальцинированная сода', 'кристаллическая сода'],
    substanceClass: 'соль',
  },
  {
    id: 'card-55',
    formula: 'Al₂O₃',
    names: ['глинозём', 'корунд'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-56',
    formula: 'AgNO₃',
    names: ['ляпис'],
    substanceClass: 'соль',
  },
  {
    id: 'card-57',
    formula: 'CO₂',
    names: ['углекислый газ'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-58',
    formula: 'KMnO₄',
    names: ['марганцовка'],
    substanceClass: 'соль',
  },
  {
    id: 'card-59',
    formula: 'Cl₂',
    names: ['хлорная вода'],
    substanceClass: 'простое вещество',
  },
  {
    id: 'card-60',
    formula: 'Na₃AlF₆',
    names: ['криолит'],
    substanceClass: 'соль',
  },
  {
    id: 'card-61',
    formula: 'MnO₂',
    names: ['пиролюзит'],
    substanceClass: 'оксид',
  },
  {
    id: 'card-62',
    formula: 'KNO₃',
    names: ['калийная селитра', 'индийская селитра'],
    substanceClass: 'соль',
  },
  {
    id: 'card-63',
    formula: 'H₂SO₄',
    names: ['серная кислота', 'купоросное масло'],
    substanceClass: 'кислота',
  },
  {
    id: 'card-64',
    formula: 'Fe₂O₃',
    names: ['гематит', 'красный железняк'],
    substanceClass: 'оксид',
  },
];

type LearningContent = Pick<ChemistryCard, 'hint1' | 'fact'>;

const learningContentByFormula: Record<string, LearningContent> = {
  CaO: {
    hint1: '«Не гашена» — ещё не встречалась с водой. Залей водой: зашипит и разогреется.',
    fact: 'Гашение — реакция СаО с водой. Прозрачный насыщенный раствор зовут известковой водой, мутную взвесь — молоком.',
  },
  Fe3O4: {
    hint1: 'Окалина — то, что «окалывается» с раскалённого железа.',
    fact: 'Внутри FeO·Fe2O3, поэтому оксид двойной. Амфотерным его называют по ошибке.',
  },
  Al2O3: {
    hint1: 'Глино-зём — земля, из которой состоит глина.',
    fact: 'Ювелирный корунд — это рубин и сапфир.',
  },
  'Al2O3·nH2O': {
    hint1: 'Главная руда алюминия.',
    fact: 'Назван по деревне Ле-Бо во Франции. Тот же глинозём, но с водой.',
  },
  H2O: {
    hint1: 'Формально — оксид водорода.',
    fact: 'Формально — оксид водорода.',
  },
  CO: {
    hint1: 'Несолеобразующий оксид.',
    fact: 'Угар — от неполного сгорания угля. Ни соли, ни кислоты не даёт.',
  },
  CO2: {
    hint1: 'Кислотный оксид.',
    fact: 'В воде даёт слабую угольную кислоту H2CO3 — отсюда «углекислый».',
  },
  N2O: {
    hint1: 'Несолеобразующий оксид.',
    fact: 'Первый наркоз в истории: пациенты смеялись прямо на столе. Кислоты не образует.',
  },
  NO2: {
    hint1: 'Кислотный оксид.',
    fact: 'Рыжий шлейф над трубой похож на лисий хвост. Ангидрид сразу двух кислот: HNO2 и HNO3.',
  },
  SO2: {
    hint1: 'Кислотный оксид.',
    fact: 'Ангидрид — «без воды»: добавь воду и получишь кислоту. SO2 + H2O → H2SO3, серн-истая: кислорода меньше.',
  },
  SO3: {
    hint1: 'Кислотный оксид.',
    fact: 'Ангидрид — «без воды»: добавь воду и получишь кислоту. SO3 + H2O → H2SO4, серная: кислорода больше.',
  },
  SiO2: {
    hint1: 'Кислотный оксид.',
    fact: 'Кремне-зём — земля, содержащая кремний. Обычный речной песок и есть SiO2.',
  },
  P2O5: {
    hint1: 'Кислотный оксид.',
    fact: 'Ангидрид — «без воды»: добавь воду и получишь кислоту. P2O5 + 3H2O → 2H3PO4, фосфорная.',
  },
  MnO2: {
    hint1: 'Амфотерный оксид.',
    fact: '«Мыть»: им осветляли стекло. Чёрный порошок, катализатор разложения H2O2. От греч. pyr — «огонь» и lysis — «разложение».',
  },
  MgO: {
    hint1: 'Основный оксид.',
    fact: '«Жжёная» — получена прокаливанием MgCO3. Ею сушат руки гимнасты и тяжелоатлеты.',
  },
  ZnO: {
    hint1: 'Амфотерный оксид.',
    fact: 'Белый пигмент для красок. Не путай с основными оксидами: ZnO амфотерный, реагирует и с кислотой, и со щёлочью.',
  },
  TiO2: {
    hint1: 'Амфотерный оксид.',
    fact: 'Самый белый из пигментов: он в краске, зубной пасте и солнцезащитном креме.',
  },
  Pb3O4: {
    hint1: 'Двойной оксид.',
    fact: 'Ярко-оранжевая краска по металлу. Внутри 2PbO·PbO2 — оксид двойной, как железная окалина.',
  },
  NaOH: {
    hint1: 'Основание.',
    fact: 'Caustic (греч. kaustikos) — «жгучий»: разъедает кожу. НатР — мужской род, едкий.',
  },
  KOH: {
    hint1: 'Основание.',
    fact: 'Тоже мужской род: едкий калий. Пара к едкому натру.',
  },
  'Ca(OH)2': {
    hint1: 'Основание.',
    fact: 'Гашение — реакция СаО с водой. Прозрачный насыщенный раствор зовут известковой водой, мутную взвесь — молоком.',
  },
  'NH3·H2O': {
    hint1: 'Основание.',
    fact: 'Резкий запах из аптечки. Не путай с нашатырём — это NH4Cl, твёрдая соль! Нашатырный спирт — раствор аммиака NH3·H2O.',
  },
  '[Ag(NH3)2]OH': {
    hint1: 'Комплексное основание.',
    fact: '«Аммиачный раствор оксида серебра»: даёт реакцию серебряного зеркала.',
  },
  HCl: {
    hint1: 'Кислота.',
    fact: '«Соляная» — её получали из поваренной соли: NaCl + H2SO4. Кислота сильная.',
  },
  HF: {
    hint1: 'Кислота.',
    fact: 'От плавикового шпата CaF2. Единственная слабая среди галогеноводородных, травит стекло.',
  },
  O3: {
    hint1: 'Простое вещество.',
    fact: 'От греч. ozon — «пахнущий»: запах свежести после грозы. Аллотропная модификация кислорода.',
  },
  C: {
    hint1: 'Простое вещество.',
    fact: 'От греч. grapho — «пишу»: им пишет карандаш. Слоистая решётка, поэтому мягкий и проводит ток.\n\nОт греч. adamas — «несокрушимый». Тот же углерод, но каждый атом связан с четырьмя соседями.',
  },
  SiC: {
    hint1: 'Бинарное соединение (карбид).',
    fact: 'Карбо (углерод) + корунд: абразив, почти такой же твёрдый, как корунд.',
  },
  NH4Cl: {
    hint1: 'Средняя соль.',
    fact: 'От храма Амона в Египте, возле которого добывали соли аммония. Нашатырь — твёрдая соль.',
  },
  PH3: {
    hint1: 'Бинарное соединение (летучее водородное).',
    fact: 'Фосфор + «ин», как у аминов. Крайне ядовит, пахнет чесноком.',
  },
  SiH4: {
    hint1: 'Бинарное соединение (летучее водородное).',
    fact: 'Si (силициум) + «-ан», по образцу метана CH4. Аналог метана у кремния.',
  },
  CS2: {
    hint1: 'Бинарное соединение (сульфид).',
    fact: 'Сера плюс углерод, и всё. Аналог CO2, где кислород заменён серой.',
  },
  COCl2: {
    hint1: 'Хлорангидрид.',
    fact: 'От греч. phos — «свет»: получен на свету. Боевое отравляющее вещество Первой мировой. Не оксид, хотя кислород в формуле есть.',
  },
  NaNO3: {
    hint1: 'Средняя соль.',
    fact: 'Её веками добывали в пустыне Атакама в Чили — отсюда второе имя.',
  },
  KNO3: {
    hint1: 'Средняя соль.',
    fact: 'Её везли из Индии. Главный компонент чёрного пороха.',
  },
  NH4NO3: {
    hint1: 'Средняя соль.',
    fact: 'Самое ходовое азотное удобрение: азот сразу в двух ионах.',
  },
  KClO3: {
    hint1: 'Средняя соль.',
    fact: 'Открыл француз Клод Бертолле. Из неё делают головки спичек. Соль хлорноватой кислоты HClO3.',
  },
  NaCl: {
    hint1: 'Средняя соль.',
    fact: '«Поваренная» — та, что у повара. «Каменная» — та, что добывают в шахтах.',
  },
  K2CO3: {
    hint1: 'Средняя соль.',
    fact: 'От англ. pot ash — «зола из горшка»: его выпаривали из древесной золы.',
  },
  Na2CO3: {
    hint1: 'Средняя соль.',
    fact: 'Кальцинировать — прокаливать; к кальцию отношения не имеет. Воды в формуле нет, водорода тоже: соль средняя.',
  },
  CaCO3: {
    hint1: 'Средняя соль.',
    fact: 'Одно вещество в трёх обличьях: рыхлый мел, кристаллический мрамор, порода известняк.',
  },
  NaHCO3: {
    hint1: 'Кислая соль.',
    fact: 'Есть «Н» в формуле — значит кислая соль. Самая частая позиция в задании 5.',
  },
  FeS2: {
    hint1: 'Средняя соль.',
    fact: 'От греч. pyr — «огонь»: искрит о сталь. Это дисульфид, соль H2S2. Сероводородной H2S отвечают сульфиды.',
  },
  'Cu2(OH)2CO3': {
    hint1: 'Основная соль.',
    fact: 'Зелёный камень и патина на медных крышах. Есть группа ОН — значит основная соль.',
  },
  Na3AlF6: {
    hint1: 'Средняя соль.',
    fact: 'От греч. kryos — «лёд»: прозрачный, как лёд. В нём плавят глинозём при выплавке алюминия.',
  },
  'Ca(H2PO4)2': {
    hint1: 'Кислая соль.',
    fact: '«Двойной» — фосфора вдвое больше, чем в простом суперфосфате. Два Н в остатке → кислая.',
  },
  KMnO4: {
    hint1: 'Средняя соль.',
    fact: 'Тёмно-фиолетовые кристаллы, розовый раствор. Соль марганцовой кислоты HMnO4.',
  },
  HgS: {
    hint1: 'Средняя соль.',
    fact: 'Красный минерал, из него веками добывали ртуть. Тот самый пигмент «вермильон».',
  },
  ZnS: {
    hint1: 'Средняя соль.',
    fact: '«Обманка» — рудокопы принимали её за свинцовую руду и оставались ни с чем. Светится в темноте.',
  },
  FeCl3: {
    hint1: 'Средняя соль.',
    fact: 'Старое название по высшей степени окисления: «хлорное» — это железо +3.',
  },
  FeCl2: {
    hint1: 'Средняя соль.',
    fact: '«истое» — низшая степень окисления, железо +2. Правило то же, что у сернистой кислоты.',
  },
  AgNO3: {
    hint1: 'Средняя соль.',
    fact: 'От лат. lapis infernalis — «адский камень»: им прижигали раны. Чернеет на свету.',
  },
  'Na2CO3·10H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Кристаллогидрат — соль с водой в решётке. Десять молекул воды дают крупные прозрачные кристаллы.',
  },
  'ZnSO4·7H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Купорос — кристаллогидрат сульфата. Смотри на металл: Zn → цинковый. Бесцветные кристаллы.',
  },
  'CuSO4·5H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Купорос — кристаллогидрат сульфата. Cu → медный. Ярко-синий, им опрыскивают деревья.',
  },
  'FeSO4·7H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Купорос — кристаллогидрат сульфата. Fe → железный. Бледно-зелёные кристаллы.',
  },
  'CaSO4·2H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Тот самый гипс на сломанной руке. Прокалить — уйдёт вода, получится алебастр.',
  },
  'Na2SO4·10H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Открыл немец Иоганн Глаубер и назвал «чудесной солью»: сильное слабительное.',
  },
  'KAl(SO4)2·12H2O': {
    hint1: 'Средняя соль (кристаллогидрат).',
    fact: 'Два металла в одной формуле — соль двойная. Ими дубили кожу и останавливали кровь.',
  },
  H2SO4: {
    hint1: 'Кислота.',
    fact: 'От лат. oleum — «масло»: тяжёлая маслянистая жидкость, дымит на воздухе.',
  },
  Cl2: {
    hint1: 'Раствор.',
    fact: 'В воде хлор частично реагирует: Cl2 + H2O ⇄ HCl + HClO. Не путай с хлорной кислотой HClO4!',
  },
  Br2: {
    hint1: 'Раствор.',
    fact: 'Жёлто-оранжевый раствор брома. Обесцвечивается непредельными углеводородами — алкенами, алкинами, алкадиенами.',
  },
};

const subscriptDigits: Record<string, string> = {
  '₀': '0',
  '₁': '1',
  '₂': '2',
  '₃': '3',
  '₄': '4',
  '₅': '5',
  '₆': '6',
  '₇': '7',
  '₈': '8',
  '₉': '9',
};

function normalizeFormula(formula: string): string {
  const normalized = formula
    .replace(/[₀-₉]/g, (digit) => subscriptDigits[digit] ?? digit)
    .replace(/\s/g, '');

  return normalized === '(CuOH)2CO3' ? 'Cu2(OH)2CO3' : normalized;
}

export const chemistryCards: ChemistryCard[] = chemistryCardsBase.map((card) => {
  const learningContent = learningContentByFormula[normalizeFormula(card.formula)];
  return {
    ...card,
    hint1: learningContent?.hint1 ?? '',
    fact: learningContent?.fact ?? '',
  };
});

export const formulaToNames: Record<string, string[]> = Object.fromEntries(
  chemistryCards.map(({ formula, names }) => [formula, [...names]]),
);

export const chemistryCardData = {
  cards: chemistryCards,
  formulaToNames,
};

let previousStartingCardId: string | null = null;

export function fisherYatesShuffle<T>(items: readonly T[]): T[] {
  const shuffled = [...items];

  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[randomIndex]] = [
      shuffled[randomIndex],
      shuffled[index],
    ];
  }

  return shuffled;
}

export function prepareGameCards(count: number): PreparedGame {
  if (!Number.isInteger(count) || count < 1 || count > chemistryCards.length) {
    throw new RangeError(
      `Количество карточек должно быть целым числом от 1 до ${chemistryCards.length}.`,
    );
  }

  const shuffledDeck = fisherYatesShuffle(chemistryCards);
  const selectedCards = shuffledDeck.slice(0, count);
  let startingIndex = Math.floor(Math.random() * selectedCards.length);

  if (
    selectedCards[startingIndex]?.id === previousStartingCardId &&
    selectedCards.length > 1
  ) {
    startingIndex = (startingIndex + 1) % selectedCards.length;
  }

  const orderedCards = [
    ...selectedCards.slice(startingIndex),
    ...selectedCards.slice(0, startingIndex),
  ];
  const cards = orderedCards.map((card, index): GameCard => {
    const nextCard = orderedCards[(index + 1) % orderedCards.length];

    if (!nextCard) {
      throw new Error('Не удалось определить следующую карточку.');
    }

    return {
      ...card,
      needs: [...(formulaToNames[nextCard.formula] ?? nextCard.names)],
    };
  });
  const startingCard = cards[0];

  if (!startingCard) {
    throw new Error('Не удалось выбрать стартовую карточку.');
  }

  previousStartingCardId = startingCard.id;
  return { cards, startingCard };
}
