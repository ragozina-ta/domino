import { useEffect, useState, type FormEvent } from 'react';
import GameScreen from '@/components/GameScreen';
import GameResults from '@/components/GameResults';
import GuideScreen from '@/components/GuideScreen';
import {
  calculateAccuracy,
  calculateElapsedMs,
  calculateStars,
  createGameSession,
  pauseGameTimer,
  playCard,
  resumeGameTimer,
  revealCurrentCardHint,
  useHint,
  type GameMode,
  type GameSession,
} from '@/game/gameLogic';
import { chemistryCards } from '@/data/chemistryCards';

const PERSONAL_BEST_KEY = 'chemical-chain:personal-best';
const GUIDE_SEEN_KEY = 'guideSeen';

function readGuideSeen(): boolean {
  if (typeof window === 'undefined') {
    return false;
  }

  try {
    return window.localStorage.getItem(GUIDE_SEEN_KEY) === 'true';
  } catch {
    return false;
  }
}

function readPersonalBest(): number {
  if (typeof window === 'undefined') {
    return 0;
  }

  try {
    const storedScore = Number(window.localStorage.getItem(PERSONAL_BEST_KEY));
    return Number.isFinite(storedScore) && storedScore > 0 ? storedScore : 0;
  } catch {
    return 0;
  }
}

type Choice = {
  value: string;
  label: string;
};

type ChoiceGroupProps = {
  label: string;
  name: string;
  value: string;
  options: Choice[];
  columns: 'two' | 'three';
  onChange: (value: string) => void;
};

function ChoiceGroup({ label, name, value, options, columns, onChange }: ChoiceGroupProps) {
  return (
    <fieldset className="field" style={{ border: 0, padding: 0, marginInline: 0 }}>
      <legend className="field-label">{label}</legend>
      <div className={`option-grid ${columns}`} role="radiogroup" aria-label={label}>
        {options.map((option) => (
          <button
            key={option.value}
            className="choice"
            type="button"
            role="radio"
            aria-checked={value === option.value}
            data-testid={`option-${name}-${option.value}`}
            onClick={() => onChange(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function App() {
  const [playerName, setPlayerName] = useState('');
  const [length, setLength] = useState('30');
  const [mode, setMode] = useState<GameMode>('training');
  const [difficulty, setDifficulty] = useState('normal');
  const [gameSession, setGameSession] = useState<GameSession | null>(null);
  const [personalBest, setPersonalBest] = useState(readPersonalBest);
  const [showGuide, setShowGuide] = useState(() => !readGuideSeen());

  useEffect(() => {
    if (!gameSession?.isComplete) {
      return;
    }

    const currentBest = readPersonalBest();
    const nextBest = Math.max(currentBest, gameSession.score);
    setPersonalBest(nextBest);

    if (gameSession.score > currentBest) {
      try {
        window.localStorage.setItem(PERSONAL_BEST_KEY, String(gameSession.score));
      } catch {
        // Keep the in-memory result visible if browser storage is unavailable.
      }
    }
  }, [gameSession]);

  function handleStart(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const handSize = difficulty === 'easy' ? 4 : difficulty === 'hard' ? 8 : 6;
    setGameSession(createGameSession(Number(length), handSize, mode));
  }

  function handleGuideContinue() {
    try {
      window.localStorage.setItem(GUIDE_SEEN_KEY, 'true');
    } catch {
      // Continue to the settings screen even when browser storage is unavailable.
    }
    setGameSession(null);
    setShowGuide(false);
  }

  function handleShowGuide() {
    setGameSession(null);
    setShowGuide(true);
  }

  if (showGuide) {
    return <GuideScreen onContinue={handleGuideContinue} />;
  }

  if (gameSession) {
    if (gameSession.isComplete) {
      return (
        <div className="app-shell game-shell">
          <GameResults
            score={gameSession.score}
            accuracy={calculateAccuracy(gameSession.correctMoves, gameSession.errors)}
            elapsedMs={calculateElapsedMs(gameSession)}
            stars={calculateStars(
              gameSession.correctMoves,
              gameSession.errors,
              gameSession.hintsUsed,
            )}
          />
        </div>
      );
    }

    return (
      <div className="app-shell game-shell">
        <GameScreen
          playerName={playerName.trim()}
          progress={gameSession.moves}
          totalMoves={gameSession.totalMoves}
          score={gameSession.score}
          chain={gameSession.chain}
          hand={gameSession.hand}
          feedback={gameSession.feedback}
          shakingCardId={gameSession.shakingCardId}
          highlightedCardId={gameSession.highlightedCardId}
          mode={gameSession.mode}
          referenceCards={chemistryCards}
          onOpenHint1={() =>
            setGameSession((current) =>
              current ? revealCurrentCardHint(current) : current,
            )
          }
          onPauseGameTimer={() =>
            setGameSession((current) =>
              current ? pauseGameTimer(current) : current,
            )
          }
          onResumeGameTimer={() =>
            setGameSession((current) =>
              current ? resumeGameTimer(current) : current,
            )
          }
          onPlayCard={(card) =>
            setGameSession((current) =>
              current ? playCard(current, card.id) : current,
            )
          }
          onUseHint={(kind) =>
            setGameSession((current) =>
              current ? useHint(current, kind) : current,
            )
          }
        />
      </div>
    );
  }

  return (
    <main className="app-shell">
      <div className="setup-layout">
        <header className="intro">
          <div className="intro-topline">
            <div className="eyebrow"><span className="eyebrow-mark" aria-hidden="true" />Химия в цепочке</div>
            <button className="show-guide-link" type="button" onClick={handleShowGuide}>Показать гид</button>
          </div>
          <h1 data-testid="text-game-title">Химическая <span>цепочка</span></h1>
          <div className="chain-art" aria-hidden="true">
            <div className="chain-line" />
            <div className="molecule molecule-one"><span>Na</span></div>
            <div className="molecule molecule-two"><span>Cl</span></div>
            <div className="molecule molecule-three"><span>H₂</span></div>
          </div>
        </header>

        <form className="form-card" onSubmit={handleStart}>
          <h2>Настройки игры</h2>
          <div className="personal-best" data-testid="text-personal-best">
            <span>Личный рекорд</span>
            <strong>{personalBest}</strong>
          </div>
          <div className="field">
            <label className="field-label" htmlFor="player-name">Имя игрока</label>
            <input
              id="player-name"
              className="name-input"
              type="text"
              value={playerName}
              onChange={(event) => setPlayerName(event.target.value)}
              placeholder="Введите имя"
              autoComplete="name"
              data-testid="input-player-name"
            />
          </div>

          <ChoiceGroup
            label="Длина цепочки"
            name="length"
            value={length}
            onChange={setLength}
            columns="three"
            options={[
              { value: '15', label: 'Короткая (15)' },
              { value: '30', label: 'Средняя (30)' },
              { value: '62', label: 'Полная (62)' },
            ]}
          />

          <ChoiceGroup
            label="Режим"
            name="mode"
            value={mode}
            onChange={(value) =>
              setMode(value === 'test' ? 'test' : 'training')
            }
            columns="two"
            options={[
              { value: 'training', label: 'Тренировка' },
              { value: 'test', label: 'Зачёт' },
            ]}
          />

          <ChoiceGroup
            label="Сложность"
            name="difficulty"
            value={difficulty}
            onChange={setDifficulty}
            columns="three"
            options={[
              { value: 'easy', label: 'Лёгкая (4 карты в руке)' },
              { value: 'normal', label: 'Обычная (6 карт в руке)' },
              { value: 'hard', label: 'Сложная (8 карт в руке)' },
            ]}
          />

          <button className="start-button" type="submit" data-testid="button-start-game">
            <span>Начать игру</span>
            <span className="button-arrow" aria-hidden="true">→</span>
          </button>
        </form>
      </div>
    </main>
  );
}

export default App;
