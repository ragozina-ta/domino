import {
  fisherYatesShuffle,
  formulaToNames,
  prepareGameCards,
  type GameCard,
} from '@/data/chemistryCards';

export type GameFeedback = {
  type: 'success' | 'error' | 'hint';
  message: string;
};

export type GameMode = 'training' | 'test';
export type HintKind = 'class' | 'removeExtras' | 'highlight';

export type GameSession = {
  chain: GameCard[];
  hand: GameCard[];
  drawPile: GameCard[];
  moves: number;
  totalMoves: number;
  score: number;
  handSize: number;
  mode: GameMode;
  isComplete: boolean;
  feedback: GameFeedback | null;
  shakingCardId: string | null;
  highlightedCardId: string | null;
  correctMoves: number;
  errors: number;
  hintsUsed: number;
  hintedCardIds: string[];
  startedAt: number;
  pausedAt: number | null;
  pausedDurationMs: number;
  finishedAt: number | null;
};

let previousInitialDeal: { contents: string; order: string } | null = null;

function shuffleHandAfterMove(
  hand: GameCard[],
  previousHand: GameCard[],
): GameCard[] {
  const shuffled = fisherYatesShuffle(hand);
  if (shuffled.length < 2) {
    return shuffled;
  }

  const previousPositions = new Map(
    previousHand.map((card, index) => [card.id, index]),
  );
  const hasPersistentCardMoved = shuffled.some(
    (card, index) =>
      previousPositions.has(card.id) &&
      previousPositions.get(card.id) !== index,
  );

  if (!hasPersistentCardMoved) {
    const persistentIndex = shuffled.findIndex((card) =>
      previousPositions.has(card.id),
    );
    if (persistentIndex >= 0) {
      const swapIndex = (persistentIndex + 1) % shuffled.length;
      [shuffled[persistentIndex], shuffled[swapIndex]] = [
        shuffled[swapIndex]!,
        shuffled[persistentIndex]!,
      ];
    }
  }

  return shuffled;
}

export function createGameSession(
  totalMoves: number,
  handSize: number,
  mode: GameMode = 'training',
): GameSession {
  if (!Number.isInteger(totalMoves) || totalMoves < 1 || totalMoves > 62) {
    throw new RangeError('Длина игры должна быть от 1 до 62 ходов.');
  }

  if (!Number.isInteger(handSize) || handSize < 1) {
    throw new RangeError('Количество карточек в руке должно быть больше нуля.');
  }

  const { cards, startingCard } = prepareGameCards(totalMoves + 1);
  const availableCards = cards.filter((card) => card.id !== startingCard.id);
  const correctCard = availableCards.find((card) =>
    isValidMove(startingCard, card),
  );

  if (!correctCard) {
    throw new Error('В колоде не найдена карточка для первого хода.');
  }

  const distractorPool = fisherYatesShuffle(
    availableCards.filter(
      (card) =>
        card.id !== correctCard.id && !isValidMove(startingCard, card),
    ),
  );
  let distractors = distractorPool.slice(0, handSize - 1);

  if (previousInitialDeal) {
    const currentContents = [correctCard, ...distractors]
      .map((card) => card.id)
      .sort()
      .join('|');

    if (currentContents === previousInitialDeal.contents && distractors.length > 0) {
      const selectedIds = new Set(distractors.map((card) => card.id));
      const replacement = distractorPool.find(
        (card) => !selectedIds.has(card.id),
      );
      if (replacement) {
        distractors = [...distractors.slice(0, -1), replacement];
      }
    }
  }

  let hand = fisherYatesShuffle([correctCard, ...distractors]);
  const handOrder = hand.map((card) => card.id).join('|');

  if (previousInitialDeal && hand.length > 1 && handOrder === previousInitialDeal.order) {
    [hand[0], hand[1]] = [hand[1]!, hand[0]!];
  }

  const handIds = new Set(hand.map((card) => card.id));
  const drawPile = fisherYatesShuffle(
    availableCards.filter((card) => !handIds.has(card.id)),
  );

  previousInitialDeal = {
    contents: hand.map((card) => card.id).sort().join('|'),
    order: hand.map((card) => card.id).join('|'),
  };

  return {
    chain: [startingCard],
    hand,
    drawPile,
    moves: 0,
    totalMoves,
    score: 0,
    handSize,
    mode,
    isComplete: false,
    feedback: null,
    shakingCardId: null,
    highlightedCardId: null,
    correctMoves: 0,
    errors: 0,
    hintsUsed: 0,
    hintedCardIds: [],
    startedAt: Date.now(),
    pausedAt: null,
    pausedDurationMs: 0,
    finishedAt: null,
  };
}

export function pauseGameTimer(
  session: GameSession,
  now = Date.now(),
): GameSession {
  if (session.isComplete || session.pausedAt !== null) {
    return session;
  }

  return { ...session, pausedAt: now };
}

export function resumeGameTimer(
  session: GameSession,
  now = Date.now(),
): GameSession {
  if (session.pausedAt === null) {
    return session;
  }

  return {
    ...session,
    pausedAt: null,
    pausedDurationMs:
      session.pausedDurationMs + Math.max(0, now - session.pausedAt),
  };
}

export function calculateElapsedMs(
  session: GameSession,
  now = Date.now(),
): number {
  const endTime = session.finishedAt ?? now;
  const ongoingPause =
    session.pausedAt === null ? 0 : Math.max(0, now - session.pausedAt);

  return Math.max(
    0,
    endTime - session.startedAt - session.pausedDurationMs - ongoingPause,
  );
}

export function revealCurrentCardHint(session: GameSession): GameSession {
  if (session.isComplete) {
    return session;
  }

  const currentCard = session.chain[session.chain.length - 1];
  if (!currentCard || session.hintedCardIds.includes(currentCard.id)) {
    return session;
  }

  return {
    ...session,
    score: session.score - (session.mode === 'test' ? 2 : 0),
    hintsUsed: session.hintsUsed + 1,
    hintedCardIds: [...session.hintedCardIds, currentCard.id],
  };
}

export function isValidMove(lastCard: GameCard, candidate: GameCard): boolean {
  const candidateNames = formulaToNames[candidate.formula];
  if (!candidateNames) {
    return false;
  }

  return lastCard.needs.some((neededName) =>
    candidateNames.includes(neededName),
  );
}

export function playCard(
  session: GameSession,
  cardId: string,
): GameSession {
  if (session.isComplete) {
    return session;
  }

  const card = session.hand.find((handCard) => handCard.id === cardId);
  const lastCard = session.chain[session.chain.length - 1];

  if (!card || !lastCard) {
    return session;
  }

  if (!isValidMove(lastCard, card)) {
    const expectedNames = lastCard.needs.join('», «');
    const actualNames = (
      formulaToNames[card.formula] ?? card.names
    ).join(', ');

    return {
      ...session,
      score: session.score - 5,
      errors: session.errors + 1,
      feedback: {
        type: 'error',
        message: `Не подходит: последняя карточка ждёт «${expectedNames}», а формула ${card.formula} означает «${actualNames}».`,
      },
      shakingCardId: card.id,
    };
  }

  const remainingHand = session.hand.filter(
    (handCard) => handCard.id !== card.id,
  );
  let nextHand = [...remainingHand];
  let nextDrawPile = [...session.drawPile];
  const moves = session.moves + 1;
  const firstCard = session.chain[0];
  const closesLoop = firstCard ? isValidMove(card, firstCard) : false;
  const isComplete = moves >= session.totalMoves && closesLoop;

  if (!isComplete) {
    const nextCardIsInHand = nextHand.some((handCard) =>
      isValidMove(card, handCard),
    );

    if (!nextCardIsInHand) {
      const nextCardIndex = nextDrawPile.findIndex((drawnCard) =>
        isValidMove(card, drawnCard),
      );

      if (nextCardIndex === -1) {
        throw new Error('В колоде не найдена карточка для продолжения цепочки.');
      }

      const nextCard = nextDrawPile.splice(nextCardIndex, 1)[0];
      if (nextCard) {
        nextHand.push(nextCard);
      }
    }

    const refillSlots = Math.max(0, session.handSize - nextHand.length);
    const distractorPool = nextDrawPile.filter(
      (drawnCard) => !isValidMove(card, drawnCard),
    );
    const nextDistractors = fisherYatesShuffle(distractorPool).slice(
      0,
      refillSlots,
    );
    const nextDistractorIds = new Set(
      nextDistractors.map((distractor) => distractor.id),
    );
    nextHand = shuffleHandAfterMove(
      [...nextHand, ...nextDistractors],
      session.hand,
    );
    nextDrawPile = fisherYatesShuffle(
      nextDrawPile.filter((drawnCard) => !nextDistractorIds.has(drawnCard.id)),
    );
  }

  return {
    ...session,
    chain: [...session.chain, card],
    hand: nextHand,
    drawPile: nextDrawPile,
    moves,
    score: session.score + 10,
    correctMoves: session.correctMoves + 1,
    isComplete,
    finishedAt: isComplete ? Date.now() : null,
    feedback: {
      type: 'success',
      message: isComplete
        ? 'Цепочка замкнулась. Игра завершена. +10 очков.'
        : 'Верно! Карточка добавлена. +10 очков.',
    },
    shakingCardId: null,
    highlightedCardId: null,
  };
}

function nextCardFor(session: GameSession): GameCard | undefined {
  const lastCard = session.chain[session.chain.length - 1];
  if (!lastCard) {
    return undefined;
  }

  return [...session.hand, ...session.drawPile].find((card) =>
    isValidMove(lastCard, card),
  );
}

function hintSuffix(mode: GameMode, cost: number): string {
  if (mode === 'training') {
    return ' В режиме «Тренировка» очки не снимаются.';
  }

  const pointsWord = cost === 8 ? 'очков' : 'очка';
  return ` Стоимость подсказки: −${cost} ${pointsWord}.`;
}

function spendHint(
  session: GameSession,
  cost: number,
  message: string,
  changes: Partial<GameSession> = {},
): GameSession {
  const pointsSpent = session.mode === 'test' ? cost : 0;
  return {
    ...session,
    ...changes,
    score: session.score - pointsSpent,
    hintsUsed: session.hintsUsed + 1,
    feedback: {
      type: 'hint',
      message: `${message}${hintSuffix(session.mode, cost)}`,
    },
    shakingCardId: null,
  };
}

export function useHint(session: GameSession, kind: HintKind): GameSession {
  if (session.isComplete) {
    return {
      ...session,
      feedback: { type: 'hint', message: 'Игра уже завершена.' },
    };
  }

  const nextCard = nextCardFor(session);
  if (!nextCard) {
    return {
      ...session,
      feedback: {
        type: 'hint',
        message: 'Подходящая карточка для подсказки не найдена.',
      },
    };
  }

  if (kind === 'class') {
    return spendHint(
      session,
      2,
      `Это ${nextCard.substanceClass}.`,
      { highlightedCardId: null },
    );
  }

  if (kind === 'removeExtras') {
    const lastCard = session.chain[session.chain.length - 1];
    if (!lastCard) {
      return session;
    }

    const extraCards = session.hand
      .filter((handCard) => !isValidMove(lastCard, handCard))
      .slice(0, 3);

    if (extraCards.length === 0) {
      return {
        ...session,
        feedback: {
          type: 'hint',
          message: 'В руке нет лишних карточек.',
        },
      };
    }

    const extraIds = new Set(extraCards.map((extraCard) => extraCard.id));
    return spendHint(
      session,
      4,
      `Лишние карточки убраны: ${extraCards.length}.`,
      {
        hand: session.hand.filter((handCard) => !extraIds.has(handCard.id)),
        drawPile: [...session.drawPile, ...extraCards],
        highlightedCardId: null,
      },
    );
  }

  let hand = [...session.hand];
  let drawPile = [...session.drawPile];
  let highlightedCard = hand.find((handCard) => isValidMove(
    session.chain[session.chain.length - 1]!,
    handCard,
  ));

  if (!highlightedCard) {
    const nextCardIndex = drawPile.findIndex((drawnCard) =>
      isValidMove(session.chain[session.chain.length - 1]!, drawnCard),
    );
    const [drawnCorrectCard] = drawPile.splice(nextCardIndex, 1);

    if (drawnCorrectCard) {
      if (hand.length >= session.handSize) {
        const lastCard = session.chain[session.chain.length - 1]!;
        const extraIndex = hand.findIndex(
          (handCard) => !isValidMove(lastCard, handCard),
        );
        if (extraIndex >= 0) {
          drawPile.push(...hand.splice(extraIndex, 1));
        }
      }
      hand.push(drawnCorrectCard);
      highlightedCard = drawnCorrectCard;
    }
  }

  if (!highlightedCard) {
    return {
      ...session,
      feedback: {
        type: 'hint',
        message: 'Верную карточку не удалось найти.',
      },
    };
  }

  return spendHint(
    session,
    8,
    'Верная карточка выделена.',
    {
      hand,
      drawPile,
      highlightedCardId: highlightedCard.id,
    },
  );
}

export function calculateAccuracy(correctMoves: number, errors: number): number {
  const attempts = correctMoves + errors;
  return attempts === 0 ? 0 : (correctMoves / attempts) * 100;
}

export function calculateStars(
  correctMoves: number,
  errors: number,
  hintsUsed: number,
): number {
  const accuracy = calculateAccuracy(correctMoves, errors);
  if (accuracy >= 95 && hintsUsed <= 3) {
    return 3;
  }
  if (accuracy >= 85) {
    return 2;
  }
  return 1;
}
