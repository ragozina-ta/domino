import { useEffect, useRef, useState, type MouseEvent } from 'react';
import type { ChemistryCard, GameCard } from '@/data/chemistryCards';
import './GameScreen.css';

function cardWord(count: number) {
  const lastTwoDigits = count % 100;
  const lastDigit = count % 10;
  if (lastTwoDigits >= 11 && lastTwoDigits <= 14) return 'карточек';
  if (lastDigit === 1) return 'карточка';
  if (lastDigit >= 2 && lastDigit <= 4) return 'карточки';
  return 'карточек';
}

type GameScreenProps = {
  playerName: string;
  progress: number;
  totalMoves: number;
  score: number;
  chain: GameCard[];
  hand: GameCard[];
  feedback: { type: 'success' | 'error' | 'hint'; message: string } | null;
  shakingCardId: string | null;
  highlightedCardId: string | null;
  mode: 'training' | 'test';
  referenceCards: ChemistryCard[];
  onOpenHint1: () => void;
  onPauseGameTimer: () => void;
  onResumeGameTimer: () => void;
  onPlayCard: (card: GameCard) => void;
  onUseHint: (kind: 'class' | 'removeExtras' | 'highlight') => void;
};

type GameDialog = 'rules' | 'reference' | 'hint1' | 'fact';

function GameScreen({
  playerName,
  progress,
  totalMoves,
  score,
  chain,
  hand,
  feedback,
  shakingCardId,
  highlightedCardId,
  mode,
  referenceCards,
  onOpenHint1,
  onPauseGameTimer,
  onResumeGameTimer,
  onPlayCard,
  onUseHint,
}: GameScreenProps) {
  const [openDialog, setOpenDialog] = useState<GameDialog | null>(null);
  const [hintMenuOpen, setHintMenuOpen] = useState(false);
  const dialogCloseRef = useRef<HTMLButtonElement>(null);
  const hintButtonRef = useRef<HTMLButtonElement>(null);
  const dialogTriggerRef = useRef<HTMLButtonElement>(null);
  const isComplete = hand.length === 0 && chain.length > 0;
  const currentChainCard = chain[chain.length - 1];
  const isLearningDialog = openDialog === 'hint1' || openDialog === 'fact';

  function closeDialog() {
    onResumeGameTimer();
    setOpenDialog(null);
    window.setTimeout(() => {
      dialogTriggerRef.current?.focus();
    }, 0);
  }

  const openGameDialog = (
    event: MouseEvent<HTMLButtonElement>,
    dialog: GameDialog,
  ) => {
    dialogTriggerRef.current = event.currentTarget;
    setHintMenuOpen(false);
    if (dialog === 'hint1') {
      onOpenHint1();
    }
    onPauseGameTimer();
    setOpenDialog(dialog);
  };

  useEffect(() => {
    if (!openDialog) return;
    dialogCloseRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeDialog();
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [openDialog]);

  const handleHint = (kind: 'class' | 'removeExtras' | 'highlight') => {
    setHintMenuOpen(false);
    onUseHint(kind);
    window.setTimeout(() => hintButtonRef.current?.focus(), 0);
  };

  return (
    <main className="game-screen">
      <header className="game-topbar">
        <div className="game-brand">
          <span className="game-brand-mark" aria-hidden="true">Х</span>
          <div>
            <p className="game-eyebrow">Химическая цепочка</p>
            <p className="game-greeting">{playerName ? `Ход игрока: ${playerName}` : 'Ваша очередь'}</p>
          </div>
        </div>

        <div className="game-stats" aria-label="Счёт и прогресс">
          <div className="game-stat">
            <span className="game-stat-label">Прогресс</span>
            <strong data-testid="text-game-progress">{progress} из {totalMoves}</strong>
          </div>
          <span className="game-stat-divider" aria-hidden="true" />
          <div className="game-stat">
            <span className="game-stat-label">Очки</span>
            <strong data-testid="text-game-score">{score}</strong>
          </div>
        </div>

        <nav className="game-tools" aria-label="Игровые инструменты">
          <button className="game-tool-button" type="button" onClick={(event) => openGameDialog(event, 'rules')} data-testid="button-rules">Правила</button>
          <button className="game-tool-button" type="button" onClick={(event) => openGameDialog(event, 'reference')} data-testid="button-reference">Справочник</button>
          <button className="game-tool-button learning-tool-button" type="button" onClick={(event) => openGameDialog(event, 'hint1')} data-testid="button-hint1">Подсказка 1</button>
          <button className="game-tool-button learning-tool-button" type="button" onClick={(event) => openGameDialog(event, 'fact')} data-testid="button-fact">Узнать новое</button>
          <div className="hint-menu-wrap">
            <button
              ref={hintButtonRef}
              className="hint-button"
              type="button"
              aria-haspopup="menu"
              aria-expanded={hintMenuOpen}
              aria-controls="hint-menu"
              onClick={() => setHintMenuOpen((open) => !open)}
              data-testid="button-hint"
            >
              <span className="hint-spark" aria-hidden="true">?</span>
              Подсказка
            </button>
            {hintMenuOpen && (
              <div className="hint-menu" id="hint-menu" role="menu" aria-label="Выберите подсказку">
                {([
                  ['class', 'Показать класс', '−2 очка'],
                  ['removeExtras', 'Убрать 3 лишние карточки', '−4 очка'],
                  ['highlight', 'Подсветить верную карточку', '−8 очков'],
                ] as const).map(([kind, label, cost]) => (
                  <button
                    className="hint-menu-option"
                    type="button"
                    role="menuitem"
                    key={kind}
                    onClick={() => handleHint(kind)}
                    data-testid={`button-hint-${kind}`}
                  >
                    <span>{label}</span>
                    <small>{mode === 'training' ? 'Бесплатно' : cost}</small>
                  </button>
                ))}
              </div>
            )}
          </div>
        </nav>
      </header>

      <section className="chain-board" aria-labelledby="chain-title">
        <div className="board-heading">
          <div>
            <p className="game-eyebrow">Поле игры</p>
            <h1 id="chain-title">Цепочка веществ</h1>
          </div>
          <span className="chain-count">{chain.length} {cardWord(chain.length)}</span>
        </div>

        <div className="chain-track" aria-label="Размещённые карточки">
          <div className="chain-track-line" aria-hidden="true" />
          {chain.length > 0 ? chain.map((card, index) => (
            <article className="placed-card" key={`${card.id}-${index}`} data-testid={`card-chain-${card.id}`}>
              <div className="placed-half placed-have">
                <span className="card-label">У меня есть:</span>
                <strong>{card.formula}</strong>
              </div>
              <span className="placed-seam" aria-hidden="true" />
              <div className="placed-half placed-need">
                <span className="card-label">Мне нужно:</span>
                <strong>{card.needs.join(', ')}</strong>
              </div>
              <span className="placed-index" aria-hidden="true">{String(index + 1).padStart(2, '0')}</span>
            </article>
          )) : (
            <div className="chain-empty">
              <span className="empty-orbit" aria-hidden="true" />
              <p>Первой карточке нужна пара</p>
              <span>Выберите подходящее вещество из руки</span>
            </div>
          )}
          {!isComplete && chain.length > 0 && (
            <div className="chain-open-end" aria-label="Открытый конец цепочки">
              <span className="open-end-dot" aria-hidden="true" />
              <span>Продолжите цепочку</span>
            </div>
          )}
        </div>

        <div className={`game-feedback${feedback ? ` is-${feedback.type}` : ''}`} role="status" aria-live="polite" aria-atomic="true" data-testid="status-game-feedback">
          <span className="feedback-indicator" aria-hidden="true" />
          <span>{feedback?.message ?? (isComplete ? 'Цепочка собрана. Отличная работа!' : 'Выберите карточку, чтобы продолжить цепочку.')}</span>
        </div>
      </section>

      <section className="hand-section" aria-labelledby="hand-title">
        <div className="hand-heading">
          <div>
            <p className="game-eyebrow">Ваш ход</p>
            <h2 id="hand-title">Карты на руке <span>{hand.length}</span></h2>
          </div>
          <p className="hand-instruction">Нажмите на карточку, чтобы сыграть</p>
        </div>

        {hand.length > 0 ? (
          <div className="hand-carousel" aria-label="Карточки игрока">
            {hand.map((card, index) => (
              <button
                className={`hand-card${shakingCardId === card.id ? ' is-shaking' : ''}${highlightedCardId === card.id ? ' is-highlighted' : ''}`}
                type="button"
                onClick={() => onPlayCard(card)}
                key={`${card.id}-${shakingCardId === card.id ? score : 'idle'}`}
                aria-label={`У меня есть: ${card.formula}. Мне нужно: ${card.needs.join(', ')}. Сыграть карточку.`}
                aria-pressed={highlightedCardId === card.id}
                data-testid={`button-play-card-${card.id}`}
              >
                <span className="hand-card-topline">
                  <span>Карточка {String(index + 1).padStart(2, '0')}</span>
                  <span className="hand-card-dot" aria-hidden="true" />
                </span>
                <span className="hand-card-half hand-card-have">
                  <span className="card-label">У меня есть:</span>
                  <strong>{card.formula}</strong>
                </span>
                <span className="hand-card-seam" aria-hidden="true" />
                <span className="hand-card-half hand-card-need">
                  <span className="card-label">Мне нужно:</span>
                  <strong>{card.needs.join(', ')}</strong>
                </span>
                <span className="hand-card-action">Сыграть <span aria-hidden="true">↗</span></span>
              </button>
            ))}
          </div>
        ) : (
          <div className="hand-empty" role="status">
            <span className="hand-empty-mark" aria-hidden="true">—</span>
            <p>{isComplete ? 'Все карточки сыграны' : 'На руке пока нет карточек'}</p>
          </div>
        )}
      </section>

      {openDialog && (
        <div className="game-dialog-backdrop" onMouseDown={(event) => {
          if (event.target === event.currentTarget) closeDialog();
        }}>
          <section
            className={`game-dialog${openDialog === 'reference' ? ' reference-dialog' : ''}${isLearningDialog ? ' learning-dialog' : ''}`}
            role="dialog"
            aria-modal="true"
            aria-labelledby="game-dialog-title"
            aria-describedby={
              openDialog === 'rules'
                ? 'game-dialog-description'
                : isLearningDialog
                  ? 'learning-dialog-description'
                  : undefined
            }
            onKeyDown={(event) => {
              if (event.key === 'Tab') {
                const focusable = event.currentTarget.querySelectorAll<HTMLElement>('button, [href], [tabindex]:not([tabindex="-1"])');
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if (event.shiftKey && document.activeElement === first) {
                  event.preventDefault();
                  last?.focus();
                } else if (!event.shiftKey && document.activeElement === last) {
                  event.preventDefault();
                  first?.focus();
                }
              }
            }}
          >
            <div className="dialog-heading">
              <div>
                <p className="game-eyebrow">
                  {openDialog === 'rules'
                    ? 'Как играть'
                    : openDialog === 'reference'
                      ? 'Таблица веществ'
                      : 'Последняя карточка цепочки'}
                </p>
                <h2 id="game-dialog-title">
                  {openDialog === 'rules'
                    ? 'Правила цепочки'
                    : openDialog === 'reference'
                      ? 'Справочник'
                      : openDialog === 'hint1'
                        ? 'Подсказка 1'
                        : 'Узнать новое'}
                </h2>
              </div>
              <button ref={dialogCloseRef} className="dialog-close" type="button" onClick={closeDialog} aria-label="Закрыть окно">×</button>
            </div>
            {isLearningDialog ? (
              <p className="learning-dialog-text" id="learning-dialog-description">
                {openDialog === 'hint1'
                  ? currentChainCard?.hint1 || 'Для этой карточки подсказки нет'
                  : currentChainCard?.fact || 'Пока ничего интересного про эту карточку'}
              </p>
            ) : openDialog === 'rules' ? (
              <ol className="rules-list" id="game-dialog-description">
                <li>На каждой карточке слева «У меня есть» (формула), справа «Мне нужно» (названия следующего вещества).</li>
                <li>Выкладывайте карточку так, чтобы её формула соответствовала названиям на последней карточке в цепочке.</li>
                <li>Название, которое «нужно», — это тривиальное название вещества. Среди нескольких названий достаточно знать одно.</li>
                <li>Неверная карточка возвращается в руку и стоит баллов.</li>
                <li>Игра закончена, когда выложены все карточки и последняя «замкнула круг» с первой.</li>
              </ol>
            ) : (
              <div className="reference-table-wrap">
                <table className="reference-table">
                  <thead><tr><th scope="col">Формула</th><th scope="col">Названия</th><th scope="col">Класс</th></tr></thead>
                  <tbody>
                    {referenceCards.map((card) => (
                      <tr key={card.id}>
                        <td className="reference-formula">{card.formula}</td>
                        <td>{card.names.join(', ')}</td>
                        <td><span className="reference-class">{card.substanceClass}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {referenceCards.length === 0 && <p className="reference-empty">Справочник пока пуст.</p>}
              </div>
            )}
            <button className="dialog-understood" type="button" onClick={closeDialog}>Понятно</button>
          </section>
        </div>
      )}
    </main>
  );
}

export default GameScreen;
