import './GameResults.css';

type GameResultsProps = {
  score: number;
  accuracy: number;
  elapsedMs: number;
  stars: number;
};

function formatElapsedTime(elapsedMs: number) {
  const totalSeconds = Math.max(0, Math.floor(elapsedMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function GameResults({ score, accuracy, elapsedMs, stars }: GameResultsProps) {
  const safeStars = Math.max(0, Math.floor(stars));
  const formattedAccuracy = `${new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 }).format(accuracy)}%`;

  return (
    <main className="results-screen">
      <section className="results-card" aria-labelledby="results-title">
        <div className="results-ornament" aria-hidden="true">
          <span className="results-orbit results-orbit-one" />
          <span className="results-orbit results-orbit-two" />
          <span className="results-chem-mark">Х</span>
        </div>
        <p className="results-eyebrow">Химическая цепочка · итог игры</p>
        <h1 id="results-title">Цепочка собрана</h1>
        <p className="results-intro">Ваш результат за эту партию</p>

        <div className="results-score" data-testid="text-result-score">
          <span>Счёт</span>
          <strong>{score}</strong>
        </div>

        <dl className="results-details">
          <div className="results-detail" data-testid="text-result-accuracy">
            <dt>Точность</dt>
            <dd>{formattedAccuracy}</dd>
          </div>
          <div className="results-detail" data-testid="text-result-time">
            <dt>Время</dt>
            <dd>{formatElapsedTime(elapsedMs)}</dd>
          </div>
        </dl>

        <div className="results-stars" data-testid="text-result-stars">
          <span>Звёзды</span>
          <strong aria-label={`${safeStars} звёзд`}>{'★'.repeat(safeStars)}</strong>
        </div>
      </section>
    </main>
  );
}

export default GameResults;
